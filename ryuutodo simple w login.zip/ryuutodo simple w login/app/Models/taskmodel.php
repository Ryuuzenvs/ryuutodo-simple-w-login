<?php
namespace App\Models;

use CodeIgniter\Model;

class taskmodel extends Model {
	protected $table = 'tasks';
	protected $primaryKey = 'id';
	protected $allowedFields = ['user_id','task_name','priority','deadline','status'];
}