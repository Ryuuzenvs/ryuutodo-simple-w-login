<head>
    <link href="<?= base_url('/assets/dist/css/bootstrap.min.css') ?>" rel="stylesheet">
    </head>
<body class="" background="<?= base_url('img103.png')?>">

    <div class="d-flex justify-content-center align-items-center vh-100">
	<form method="post" action="<?= base_url('update/' . $task['id'])?>" class="p-4" style="background-color: rgba(255, 255, 255, 0.7);">
        <h3 class="text-center">edit</h3>
        <div class="form-group">
            <label for="name">task name</label>
            <input type="text" id="name" name="name" class="form-control" value="<?= $task['task_name']?>" required>
        </div>
        <div class="form-group">
    <label for="priority">prioritas</label>
    <select id="priority" name="priority" class="form-select">
        <option value="Biasa" <?= ($task['priority'] == 'Biasa') ? 'selected' : '' ?>>biasa</option>
        <option value="Penting" <?= ($task['priority'] == 'Penting') ? 'selected' : '' ?>>penting</option>
    </select>
</div>
		<div class="form-group">
            <label for="deadline">deadline</label>
            <input type="date" id="deadline" name="deadline" class="form-control" value="<?= esc($task['deadline'])?>" required>
        </div>
        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-success mt-4">save</button>
			<a href="<?= base_url('dashboard')?>" class="btn btn-outline-primary mt-2">back</a>
        </div>
		
    </form>
	
	</div>

</body>