<head>
    <link href="<?= base_url('/assets/dist/css/bootstrap.min.css') ?>" rel="stylesheet">
    </head>
<body class="" style="background-size: cover;" background="<?= base_url('img103.png')?>">

    <div class="d-flex justify-content-center align-items-center vh-100">
	<form method="post" action="<?= base_url('loginprocess')?>" class="p-4" style="background-color: rgba(255, 255, 255, 0.7);">
        <h3 class="text-center">Login</h3>
        <div class="form-group">
            <label for="username">username</label>
            <input type="text" id="username" name="username" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="password">password</label>
            <input type="password" id="password" name="password" class="form-control" required>
        </div>
        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-success mt-4">login</button>
        </div>
    </form>
	</div>

</body>