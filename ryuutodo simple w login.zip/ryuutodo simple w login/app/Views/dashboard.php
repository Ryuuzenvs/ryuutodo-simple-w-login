
    <a href="<?= base_url('create')?>" class="btn btn-outline-primary">buat</a>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Nama Tugas</th>
                <th>Prioritas</th>
                <th>Deadline</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($tasks)) : ?>
                <tr>
                    <td colspan="4" class="text-center">Belum ada tugas yang ditambahkan.</td>
                </tr>
            <?php else : ?>
                <?php foreach($tasks as $task) : ?>
                    <tr>
                        <td><?= esc($task['task_name'])?></td>
                        <td><?= esc($task['priority'])?></td>
                        <td><?= esc($task['deadline'])?></td>
                        <td>
                            <a href="<?= base_url('edit/' . $task['id'])?>" class="btn btn-warning btn-sm"><i class="fas fa-pen"></i></a>
                            <?php
                            $status_class = ($task['status'] == 'Belum') ? 'danger' : 'success';
                            $status_icon = ($task['status'] == 'Belum') ? 'times' : 'check';
                            ?>
                            <a href="<?= base_url('status/' . $task['id'])?>" class="btn btn-<?= $status_class?> btn-sm"><i class="fas fa-<?= $status_icon?>"></i></a>
                            <a href="<?= base_url('delete/' . $task['id'])?>" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbicon
    </table>
    <a href="<?= base_url('logout')?>" class="btn btn-outline-danger">logout</a>
