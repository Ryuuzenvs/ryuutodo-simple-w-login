<?php 
namespace App\Controllers;

use App\Models\taskmodel;
use CodeIgniter\Controller;

class task extends BaseController {
	protected $taskmodel;
	public function __construct(){
		$this->taskmodel = new taskmodel();
	}
	public function index(){
		//variable get id user in session
		$userid = session()->get('user_id');
		//cek login
		if(!session()->get('islogin')){
			return redirect()->to('/')->with('error', 'login dulu');
		}
		
		//declaration variable task for return in view 
		$tasks = $this->taskmodel
		//value :  taskmodel get data by id user in login session
		->where('user_id', $userid)
		// get all row for the true condision
		->findAll();
		echo view('header');
		echo view('sidebar');
		return view('dashboard', ['tasks' => $tasks]);
		echo view('footer');
	}
	public function store(){
		if(!session()->get('islogin')){
			return redirect()->to('/');
		}
		
		$data = [
		'task_name'=> $this->request->getPost('name'),
		'priority' => $this->request->getPost('prioritas'),
		'deadline' => $this->request->getPost('deadline'),
		];

		
		$data['user_id'] = session()->get('user_id');
		$data ['status']= 'Belum';
		
		$this->taskmodel->insert($data);
		
		return redirect()->to(base_url('dashboard'))->with('success', 'berhasil di tambah');
	}
	
	public function update($id = null){
		$userid = session()->get('user_id');
		if(!session()->get('islogin')){
			return redirect()->to('/');
		}
		
		$data = [
		'task_name'=> $this->request->getPost('name'),
		'priority' => $this->request->getPost('priority'),
		'deadline' => $this->request->getPost('deadline'),
		];
		
		$task = $this->taskmodel->where('user_id', $userid)->find($id);
		
		if(empty($task)){
			return redirect()->to('/dashboard')->with('erorr', 'ga ditemukan');
		}
		
		$this->taskmodel->update($id,$data);
		
		return redirect()->to('/dashboard')->with('success', 'yo');
	}
	
	public function delete($id = null){
		$userid = session()->get('user_id');
		if(!session()->get('islogin')){
			return redirect()->to('/');
		}
		
		$task = $this->taskmodel->where('user_id', $userid)->find($id);
		
		if($task){
			$this->taskmodel->delete($id);
			return redirect()->back()->with('success', 'yo');
		} else {
			return redirect()->back()->with('erorr', 'ga bisa');
		}
	}
	public function status($id = null){
		$userid = session()->get('user_id');
		if(!session()->get('islogin')){
			return redirect()->to('/');
		}
		
		$task = $this->taskmodel->where('user_id', $userid)->find($id);
		
		if($task){
			$newstatus = ($task['status'] == 'Belum') ? 'Selesai' : 'Belum';
			$data = [
			'status' => $newstatus
			];
			$this->taskmodel->update($id,$data);
			return redirect()->back()->with('success', 's');
		} else {
			return redirect()->back()->with('error', 'e');
		}
	}
	
}