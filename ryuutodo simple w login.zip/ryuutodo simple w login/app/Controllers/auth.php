<?php
namespace App\Controllers;

use App\Models\usermodel;
use CodeIgniter\Controller;

class Auth extends Controller {
	
	protected $userModel;
	
	public function __construct (){
		$this->userModel = new usermodel();
	}

	public function login (){
		return view('login');
	}
	
	public function loginprocess(){
		$username = $this->request->getPost('username');
		$password = $this->request->getPost('password');
		
		$user = $this->userModel->where('username', $username)->first();
		
		if($user){
			if(password_verify($password, $user['password'])){
				$session = session();
				$sessionData = [
				'user_id' => $user['id'],
				'username' => $user['username'],
				'islogin' => true
				];
				$session->set($sessionData);
				return redirect()->to(base_url('dashboard'));
			} else {
				session()->setFlashdata('error', 'Username atau password salah.');
				return redirect()->to(base_url('/'));
			}
		} else {
			session()->setFlashdata('error', 'Username atau password salah.');
			return redirect()->to(base_url('/'));
		}
	}
	
	public function logout(){
		session()->destroy();
		return redirect()->to('/');
	}
}