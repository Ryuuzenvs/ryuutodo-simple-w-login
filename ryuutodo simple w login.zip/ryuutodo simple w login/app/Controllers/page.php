<?php 
namespace App\Controllers;

use App\Models\taskmodel;
use CodeIgniter\Controller;

class page extends Controller {
	public function __construct(){
		$this->taskmodel = new taskmodel();
	}
	public function create(){
		return view('create');
	}
	public function edit($id = null){
		//variable get id user in session
		$userid = session()->get('user_id');
		//cek login
		if(!session()->get('islogin')){
			return redirect->to('/')->with('error', 'login dulu');
		}
		
		//declaration variable task for return in view 
		$tasks = $this->taskmodel
		//value :  taskmodel get data by id user in login session
		->where('user_id', $userid)
		// get all row for the true condision
		->find($id);
		return view('edit', [
		'task' => $tasks
		]);
	}
}