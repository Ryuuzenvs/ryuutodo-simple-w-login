<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'auth::login');
$routes->post('/loginprocess', 'Auth::loginprocess');
$routes->get('/dashboard', 'task::index');
$routes->get('/create', 'page::create');
$routes->post('/store', 'task::store');
$routes->post('/update/(:num)', 'task::update/$1');
$routes->get('/edit/(:num)', 'page::edit/$1');
$routes->get('/status/(:num)', 'task::status/$1');
$routes->get('/delete/(:num)', 'task::delete/$1');
$routes->get('/logout', 'auth::logout');
